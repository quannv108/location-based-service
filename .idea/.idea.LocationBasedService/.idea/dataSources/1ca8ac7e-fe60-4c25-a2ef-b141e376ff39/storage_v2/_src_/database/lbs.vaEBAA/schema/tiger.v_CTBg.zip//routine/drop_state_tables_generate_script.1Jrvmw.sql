create function drop_state_tables_generate_script(param_state text, param_schema text DEFAULT 'tiger_data'::text) returns text
    language sql
as
$$
SELECT array_to_string(array_agg('DROP TABLE ' || quote_ident(table_schema) || '.' || quote_ident(table_name) || ';'),E'\n')
	FROM (SELECT * FROM information_schema.tables
	WHERE table_schema = $2 AND table_name like lower($1) || '~_%' ESCAPE '~' ORDER BY table_name) AS foo;
;
$$;

comment on function drop_state_tables_generate_script(text, text) is 'args: param_state, param_schema=tiger_data - Generates a script that drops all tables in the specified schema that are prefixed with the state abbreviation. Defaults schema to tiger_data if no schema is specified.';

alter function drop_state_tables_generate_script(text, text) owner to postgres;

