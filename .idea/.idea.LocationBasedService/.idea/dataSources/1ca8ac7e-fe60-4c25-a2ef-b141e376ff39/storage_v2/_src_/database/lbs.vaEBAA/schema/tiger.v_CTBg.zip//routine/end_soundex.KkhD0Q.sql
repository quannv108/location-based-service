create function end_soundex(character varying) returns character varying
    immutable
    language plpgsql
as
$$
DECLARE
  tempString VARCHAR;
BEGIN
  tempString := substring($1, E'[ ,.\n\t\f]([a-zA-Z0-9]*)$');
  IF tempString IS NOT NULL THEN
    tempString := soundex(tempString);
  ELSE
    tempString := soundex($1);
  END IF;
  return tempString;
END;
$$;

alter function end_soundex(varchar) owner to postgres;

