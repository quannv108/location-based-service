create function install_missing_indexes() returns boolean
    language plpgsql
as
$$
DECLARE var_sql text = missing_indexes_generate_script();
BEGIN
	EXECUTE(var_sql);
	RETURN true;
END
$$;

comment on function install_missing_indexes() is 'Finds all tables with key columns used in geocoder joins and filter conditions that are missing used indexes on those columns and will add them.';

alter function install_missing_indexes() owner to postgres;

