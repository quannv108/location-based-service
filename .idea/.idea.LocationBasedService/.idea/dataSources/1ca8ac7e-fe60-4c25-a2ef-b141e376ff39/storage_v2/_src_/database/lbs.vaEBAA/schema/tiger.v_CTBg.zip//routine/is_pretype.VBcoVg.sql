create function is_pretype(text) returns boolean
    immutable
    strict
    language sql
as
$$
    SELECT EXISTS(SELECT name FROM street_type_lookup WHERE upper(name) = upper($1) AND is_hw );
$$;

alter function is_pretype(text) owner to postgres;

