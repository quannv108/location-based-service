create function levenshtein_ignore_case(character varying, character varying) returns integer
    immutable
    language sql
as
$$
  SELECT levenshtein(COALESCE(upper($1),''), COALESCE(upper($2),''));
$$;

alter function levenshtein_ignore_case(varchar, varchar) owner to postgres;

