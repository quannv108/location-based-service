create function loader_macro_replace(param_input text, param_keys text[], param_values text[]) returns text
    immutable
    language plpgsql
as
$$
	DECLARE var_result text = param_input;
	DECLARE var_count integer = array_upper(param_keys,1);
	BEGIN
		FOR i IN 1..var_count LOOP
			var_result := replace(var_result, '${' || param_keys[i] || '}', param_values[i]);
		END LOOP;
		return var_result;
	END;
$$;

alter function loader_macro_replace(text, text[], text[]) owner to postgres;

