create function set_geocode_setting(setting_name text, setting_value text) returns text
    language sql
as
$$
INSERT INTO geocode_settings(name, setting, unit, category, short_desc)
SELECT name, setting, unit, category, short_desc
    FROM geocode_settings_default
    WHERE name NOT IN(SELECT name FROM geocode_settings);

UPDATE geocode_settings SET setting = $2 WHERE name = $1
	RETURNING setting;
$$;

comment on function set_geocode_setting(text, text) is 'args:  setting_name,  setting_value - Sets a setting that affects behavior of geocoder functions.';

alter function set_geocode_setting(text, text) owner to postgres;

