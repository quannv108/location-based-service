create function _st_mintolerance(ageom geometry) returns double precision
    immutable
    strict
    language sql
as
$$
    SELECT 3.6 * power(10,  - ( 15 - log(coalesce(
      nullif(
        greatest(abs(ST_xmin($1)), abs(ST_ymin($1)),
                 abs(ST_xmax($1)), abs(ST_ymax($1))),
        0),
      1)) ));
$$;

alter function _st_mintolerance(geometry) owner to postgres;

