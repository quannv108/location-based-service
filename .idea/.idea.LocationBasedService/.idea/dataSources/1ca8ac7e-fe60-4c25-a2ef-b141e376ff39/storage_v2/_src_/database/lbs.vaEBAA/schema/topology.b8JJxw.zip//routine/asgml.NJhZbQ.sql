create function asgml(tg topogeometry, nsprefix text, prec integer, opts integer) returns text
    stable
    language sql
as
$$
 SELECT topology.AsGML($1, $2, $3, $4, NULL);
$$;

comment on function asgml(topogeometry, text, integer, integer) is 'args: tg, nsprefix_in, precision, options - Returns the GML representation of a topogeometry.';

alter function asgml(topogeometry, text, integer, integer) owner to postgres;

