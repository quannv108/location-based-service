create function createtopology(character varying, integer) returns integer
    strict
    language sql
as
$$ SELECT topology.CreateTopology($1, $2, 0); $$;

comment on function createtopology(varchar, integer) is 'args: topology_schema_name, srid - Creates a new topology schema and registers it in the topology.topology table.';

alter function createtopology(varchar, integer) owner to postgres;

