create function findlayer(topology_id integer, layer_id integer) returns layer
    language sql
as
$$
    SELECT * FROM topology.layer
    WHERE topology_id = $1
      AND layer_id = $2
$$;

comment on function findlayer(integer, integer) is 'args: topology_id, layer_id - Returns a topology.layer record by different means.';

alter function findlayer(integer, integer) owner to postgres;

