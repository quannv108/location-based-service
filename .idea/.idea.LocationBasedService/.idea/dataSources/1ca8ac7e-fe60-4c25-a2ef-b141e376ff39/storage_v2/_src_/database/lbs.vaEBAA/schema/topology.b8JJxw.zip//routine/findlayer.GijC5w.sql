create function findlayer(layer_table regclass, feature_column name) returns layer
    language sql
as
$$
    SELECT l.*
    FROM topology.layer l, pg_class c, pg_namespace n
    WHERE l.schema_name = n.nspname
    AND l.table_name = c.relname
    AND c.oid = $1
    AND c.relnamespace = n.oid
    AND l.feature_column = $2
$$;

comment on function findlayer(regclass, name) is 'args: layer_table, feature_column - Returns a topology.layer record by different means.';

alter function findlayer(regclass, name) owner to postgres;

