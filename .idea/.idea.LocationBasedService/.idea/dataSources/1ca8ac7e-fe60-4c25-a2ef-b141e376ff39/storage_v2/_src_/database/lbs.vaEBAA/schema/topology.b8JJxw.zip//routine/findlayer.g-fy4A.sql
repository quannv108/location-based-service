create function findlayer(tg topogeometry) returns layer
    language sql
as
$$
    SELECT * FROM topology.layer
    WHERE topology_id = topology_id($1)
    AND layer_id = layer_id($1)
$$;

comment on function findlayer(topogeometry) is 'args: tg - Returns a topology.layer record by different means.';

alter function findlayer(topogeometry) owner to postgres;

