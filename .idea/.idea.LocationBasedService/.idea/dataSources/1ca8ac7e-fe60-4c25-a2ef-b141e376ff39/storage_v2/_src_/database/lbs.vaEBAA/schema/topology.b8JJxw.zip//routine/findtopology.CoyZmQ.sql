create function findtopology(regclass, name) returns topology
    language sql
as
$$
    SELECT t.*
    FROM topology.topology t
    JOIN topology.layer l ON (t.id = l.topology_id)
    WHERE format('%I.%I', l.schema_name, l.table_name)::regclass = $1
    AND l.feature_column = $2;
$$;

comment on function findtopology(regclass, name) is 'args: layerTable, layerColumn - Returns a topology record by different means.';

alter function findtopology(regclass, name) owner to postgres;

