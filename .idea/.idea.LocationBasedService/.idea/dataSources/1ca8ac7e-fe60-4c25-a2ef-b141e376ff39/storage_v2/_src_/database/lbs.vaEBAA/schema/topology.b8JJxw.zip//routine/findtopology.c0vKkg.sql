create function findtopology(topogeometry) returns topology
    language sql
as
$$
    SELECT * FROM topology.topology
    WHERE id = topology_id($1);
$$;

comment on function findtopology(topogeometry) is 'args: topogeom - Returns a topology record by different means.';

alter function findtopology(topogeometry) owner to postgres;

