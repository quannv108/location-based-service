create function findtopology(name, name, name) returns topology
    language sql
as
$$
    SELECT t.*
    FROM topology.topology t
    JOIN topology.layer l ON (t.id = l.topology_id)
    WHERE l.schema_name = $1
    AND l.table_name = $2
    AND l.feature_column = $3;
$$;

comment on function findtopology(name, name, name) is 'args: layerSchema, layerTable, layerColumn - Returns a topology record by different means.';

alter function findtopology(name, name, name) owner to postgres;

