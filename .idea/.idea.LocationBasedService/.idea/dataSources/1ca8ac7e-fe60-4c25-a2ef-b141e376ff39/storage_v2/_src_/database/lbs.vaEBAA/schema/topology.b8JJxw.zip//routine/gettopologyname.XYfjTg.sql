create function gettopologyname(topoid integer) returns character varying
    stable
    strict
    language plpgsql
as
$$
DECLARE
  ret varchar;
BEGIN
        SELECT name FROM topology.topology into ret
                WHERE id = topoid;
  RETURN ret;
END
$$;

comment on function gettopologyname(integer) is 'args: topology_id - Returns the name of a topology (schema) given the id of the topology.';

alter function gettopologyname(integer) owner to postgres;

