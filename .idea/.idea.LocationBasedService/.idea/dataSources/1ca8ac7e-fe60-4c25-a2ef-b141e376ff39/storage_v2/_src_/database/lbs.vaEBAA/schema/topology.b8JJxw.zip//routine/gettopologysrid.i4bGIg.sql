create function gettopologysrid(toponame character varying) returns integer
    stable
    strict
    language sql
as
$$
  SELECT SRID FROM topology.topology WHERE name = $1;
$$;

alter function gettopologysrid(varchar) owner to postgres;

