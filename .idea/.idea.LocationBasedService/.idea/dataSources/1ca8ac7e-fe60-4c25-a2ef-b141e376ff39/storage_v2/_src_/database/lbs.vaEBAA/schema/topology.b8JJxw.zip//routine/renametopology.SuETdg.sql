create function renametopology(old_name character varying, new_name character varying) returns character varying
    strict
    language plpgsql
as
$$
DECLARE
  sql text;
BEGIN

  sql := format(
    'ALTER SCHEMA %I RENAME TO %I',
    old_name, new_name
  );
  EXECUTE sql;

  sql := format(
    'UPDATE topology.topology SET name = %L WHERE name = %L',
    new_name, old_name
  );
  EXECUTE sql;

  RETURN new_name;
END
$$;

comment on function renametopology(varchar, varchar) is 'args: old_name, new_name - Renames a topology';

alter function renametopology(varchar, varchar) owner to postgres;

