create function st_srid(tg topogeometry) returns integer
    strict
    language sql
as
$$
	SELECT srid FROM topology.topology
  WHERE id = topology_id(tg);
$$;

comment on function st_srid(topogeometry) is 'args: tg - Returns the spatial reference identifier for a topogeometry.';

alter function st_srid(topogeometry) owner to postgres;

