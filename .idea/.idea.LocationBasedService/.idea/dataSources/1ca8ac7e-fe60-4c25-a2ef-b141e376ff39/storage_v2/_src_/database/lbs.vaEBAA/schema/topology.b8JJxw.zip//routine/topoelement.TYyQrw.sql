create function topoelement(topo topogeometry) returns topoelement
    immutable
    parallel safe
    cost 1
    language sql
as
$$SELECT ARRAY[topo.id,topo.layer_id]::topology.topoelement;$$;

comment on function topoelement(topogeometry) is 'args: topo - Converts a topogeometry to a topoelement.';

alter function topoelement(topogeometry) owner to postgres;

